import { Component, OnInit } from '@angular/core';
//import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  

  title = 'Employee Details';
  constructor (private httpService: HttpClient) { }
  showContainer: boolean = false;
  closeContainer: boolean = true;
  arrEmp: string [];

  ngOnInit () {
    this.httpService.get('./assets/employee.json').subscribe(
      data => {
        this.arrEmp = data as string [];	 // FILL THE ARRAY WITH DATA.
        console.log(this.arrEmp[0]);
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );
  }

}
